
# Zittar — سایت معرفی محصول (+مقالات) — بدون فروش آنلاین

این پکیج شامل:
- `site/` — وب‌سایت معرفی (HTML/CSS/JS) با صفحات «خانه»، «محصولات»، «مقاله‌ها»، «درباره»، «ارتباط» و «ادمین»
- `server/` — بک‌اند سبک (Express + SQLite) فقط برای **مدیریت مقاله‌ها** و احراز هویت ادمین

## اجرا
```bash
cd server
npm i
# اختیاری: تغییر ایمیل/رمز ادمین و کلید سشن
# export ADMIN_EMAIL="admin@zittar.local"
# export ADMIN_PASSWORD="رمز_قوی"
# export SESSION_SECRET="کلید_خیلی_قوی"
npm start
```
به `http://localhost:5173` بروید.

### ورود ادمین
- ایمیل: `admin@zittar.local`
- رمز: `zittar123`  ← لطفاً در محیط واقعی تغییر دهید.

## API
- `POST /api/login` — ورود `{email,password}`
- `POST /api/logout` — خروج
- `GET /api/me` — کاربر جاری
- `GET /api/articles` — دریافت مقاله‌ها (عمومی: فقط منتشرشده)
- `POST /api/articles` — افزودن مقاله (ادمین، `multipart/form-data`)
- `DELETE /api/articles/:id` — حذف مقاله (ادمین)

## نکات
- صفحه محصولات فقط برای **معرفی** است؛ هر کارت دکمه‌ی «تماس و استعلام» دارد که به صفحه‌ی ارتباط می‌رود و نام محصول را در پیام **پیش‌فرض** می‌گذارد.
- صفحه ادمین فقط مدیریت مقاله‌ها را نمایش می‌دهد (سفارش/خرید حذف شده است).
- لوگوی واقعی‌تان را با فایل `site/assets/logo.png` جایگزین کنید (یا `logo.svg`).

## استقرار پیشنهادی
VPS کوچک + Nginx (reverse proxy) + pm2. دیتابیس فایل `server/data/zittar.db` است (بکاپ منظم بگیرید).

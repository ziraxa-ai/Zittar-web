
import express from 'express';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import cors from 'cors';
import cookieSession from 'cookie-session';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5173;

const DB_PATH = path.resolve(__dirname, 'data', 'zittar.db');
const UPLOAD_DIR = path.resolve(__dirname, 'uploads', 'articles');
const SITE_DIR = path.resolve(__dirname, '../site');

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// DB
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS articles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT DEFAULT (datetime('now')),
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  tags TEXT,
  image_path TEXT,
  published INTEGER DEFAULT 1
);
`);

// Seed admin
const adminEmail = process.env.ADMIN_EMAIL || 'admin@zittar.local';
const adminPass = process.env.ADMIN_PASSWORD || 'zittar123';
const adminExists = db.prepare('SELECT id FROM users WHERE email=?').get(adminEmail);
if (!adminExists){
  const hash = bcrypt.hashSync(adminPass, 10);
  db.prepare('INSERT INTO users(email, password_hash, role) VALUES(?,?,?)').run(adminEmail, hash, 'admin');
  console.log('Seeded admin user:', adminEmail);
}

// middleware
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '2mb' }));
app.use(cookieSession({ name: 'zittar_sess', keys: [process.env.SESSION_SECRET || 'devsecret'], maxAge: 7*24*60*60*1000 }));

// static
app.use(express.static(SITE_DIR));
app.use('/uploads', express.static(path.resolve(__dirname, 'uploads')));

// helpers
function auth(req, res, next){ if (req.session?.user?.role === 'admin') return next(); return res.status(401).json({error:'unauthorized'}); }

// uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase();
    const safe = String(Date.now()) + '-' + Math.random().toString(36).slice(2) + (ext || '.jpg');
    cb(null, safe);
  }
});
const upload = multer({ storage });

// auth endpoints
app.post('/api/login', (req, res) => {
  const { email, password } = req.body || {};
  const u = db.prepare('SELECT * FROM users WHERE email=?').get(email || '');
  if (!u) return res.status(401).json({error:'invalid'});
  if (!bcrypt.compareSync(password || '', u.password_hash)) return res.status(401).json({error:'invalid'});
  req.session.user = { id: u.id, email: u.email, role: u.role };
  res.json({ ok: true, role: u.role });
});
app.post('/api/logout', (req, res) => { req.session = null; res.json({ok:true}) });
app.get('/api/me', (req, res) => res.json(req.session?.user || {role:'guest'}));

// articles
app.get('/api/articles', (req, res) => {
  const all = req.query.all === '1' || req.query.all === 'true';
  if (all && !(req.session?.user?.role === 'admin')){
    return res.status(401).json({error:'unauthorized'});
  }
  const where = all ? '' : 'WHERE published=1';
  const rows = db.prepare(`SELECT id, created_at, title, body, tags, image_path, published FROM articles ${where} ORDER BY id DESC`).all();
  res.json(rows.map(r => ({
    id: r.id, created_at: r.created_at, title: r.title, body: r.body,
    tags: (r.tags || '').split(',').map(s=>s.trim()).filter(Boolean),
    image_url: r.image_path ? '/uploads/articles/' + path.basename(r.image_path) : '',
    published: !!r.published
  })));
});
app.post('/api/articles', auth, upload.single('image'), (req, res) => {
  const { title='', body='', tags='', published='1' } = req.body || {};
  if (!title.trim() || !body.trim()) return res.status(400).json({error:'title/body required'});
  const imgPath = req.file ? req.file.path : null;
  const stmt = db.prepare('INSERT INTO articles (title, body, tags, image_path, published) VALUES (?,?,?,?,?)');
  const info = stmt.run(title.trim(), body.trim(), String(tags||''), imgPath, (published==='1'||published===1)?1:0);
  res.json({ id: info.lastInsertRowid });
});
app.delete('/api/articles/:id', auth, (req, res) => {
  const id = Number(req.params.id || 0);
  const row = db.prepare('SELECT image_path FROM articles WHERE id=?').get(id);
  db.prepare('DELETE FROM articles WHERE id=?').run(id);
  if (row?.image_path){ try{ fs.unlinkSync(row.image_path) }catch(e){} }
  res.json({ok:true});
});

// fallback: serve site index
app.get('*', (req, res) => res.sendFile(path.join(SITE_DIR, 'index.html')));

app.listen(PORT, () => console.log('Zittar showcase server on http://localhost:'+PORT));


(() => {
  const $ = (sel, root=document) => root.querySelector(sel);
  const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));
  const PAGE = document.body.dataset.page;

  // Mobile nav
  const toggle = $('.nav-toggle');
  const menu = $('.menu');
  if (toggle && menu){
    toggle.addEventListener('click', () => {
      menu.classList.toggle('open');
      toggle.setAttribute('aria-expanded', menu.classList.contains('open') ? 'true':'false');
    });
  }

  // Highlight current
  if (PAGE){ $$(`.menu a[data-page="${PAGE}"]`).forEach(a => a.setAttribute('aria-current','page')); }

  // 3D tilt tiles
  $$('.tile').forEach(card => {
    const strength = 10;
    const rect = () => card.getBoundingClientRect();
    const enter = () => card.style.transition = 'transform .07s ease';
    const leave = () => { card.style.transition = 'transform .25s ease'; card.style.transform = ''; }
    const move = (x, y) => {
      const r = rect();
      const px = (x - r.left) / r.width;
      const py = (y - r.top) / r.height;
      const rx = (py - .5) * strength;
      const ry = (px - .5) * -strength;
      card.style.transform = `translateY(-8px) rotateX(${rx}deg) rotateY(${ry}deg)`;
    };
    card.addEventListener('mousemove', e => move(e.clientX, e.clientY));
    card.addEventListener('mouseenter', enter);
    card.addEventListener('mouseleave', leave);
    card.addEventListener('touchstart', () => card.style.transform='translateY(-6px) scale(1.01)', {passive:true});
    card.addEventListener('touchend', () => card.style.transform='', {passive:true});
  });

  // Products page (showcase only)
  if (PAGE === 'products'){
    const products = [
      {id:1, name:'زیتون سبز ویژه دِهچ',  cat:'زیتونیا', price:175000, unit:'گرم', img:'assets/tile-olive.svg', tags:['بی‌هسته','نمک ملایم']},
      {id:2, name:'زیتون سیاه کنسروی',     cat:'زیتونیا', price:189000, unit:'گرم', img:'assets/tile-olive.svg', tags:['مدیترانه‌ای']},
      {id:3, name:'روغن زیتون فرابکر 500ml',cat:'زیتونیا', price:420000, unit:'بطری', img:'assets/tile-olive.svg', tags:['سردفشار']},
      {id:4, name:'سماق ارگانیک',           cat:'خوش‌دونه', price:98000, unit:'گرم', img:'assets/tile-seed.svg', tags:['آسیاب تازه']},
      {id:5, name:'کنجد بو داده',            cat:'خوش‌دونه', price:76000, unit:'گرم', img:'assets/tile-seed.svg', tags:['عطر بالا']},
      {id:6, name:'ترشی بادمجان خانگی',     cat:'ترشی‌بار', price:155000, unit:'گرم', img:'assets/tile-pickle.svg', tags:['دست‌ساز']},
      {id:7, name:'ترشی مخلوط ویژه',        cat:'ترشی‌بار', price:132000, unit:'گرم', img:'assets/tile-pickle.svg', tags:['بدون مواد نگهدارنده']},
      {id:8, name:'سس انار',                 cat:'چاشنی‌چی', price:99000, unit:'بطری', img:'assets/tile-spice.svg', tags:['ملس']},
      {id:9, name:'رب نارنج',                cat:'چاشنی‌چی', price:119000, unit:'بطری', img:'assets/tile-spice.svg', tags:['طبیعی']},
      {id:10,name:'شربت به‌لیمو',            cat:'جرعه‌ی بهار', price:145000, unit:'بطری', img:'assets/tile-syrup.svg', tags:['خنک‌کننده']},
      {id:11,name:'شربت غوره',              cat:'جرعه‌ی بهار', price:125000, unit:'بطری', img:'assets/tile-syrup.svg', tags:['دست‌پخت']},
      {id:12,name:'ادویه سالاد مدیترانه',   cat:'چاشنی‌چی', price:86000, unit:'گرم', img:'assets/tile-spice.svg', tags:['ترکیب اختصاصی']},
    ];
    const grid = document.querySelector('.products');
    const chips = Array.from(document.querySelectorAll('.chip[data-cat]'));
    const search = document.querySelector('#search');
    const sort = document.querySelector('#sort');
    const formatPrice = n => n.toLocaleString('fa-IR') + ' تومان';

    const render = () => {
      const q = (search?.value || '').trim();
      const active = chips.filter(c=>c.classList.contains('active')).map(c=>c.dataset.cat);
      const sorted = [...products]
        .filter(p => (active.length ? active.includes(p.cat) : true))
        .filter(p => (q ? (p.name.includes(q) || p.tags.some(t=>t.includes(q))) : true))
        .sort((a,b) => {
          switch (sort?.value){
            case 'price_asc': return a.price - b.price;
            case 'price_desc': return b.price - a.price;
            case 'name': return a.name.localeCompare(b.name, 'fa');
            default: return 0;
          }
        });

      grid.innerHTML = sorted.map(p => `
        <div class="product">
          <div class="thumb"><img src="${p.img}" alt="${p.name}"></div>
          <div class="body">
            <strong>${p.name}</strong>
            <div class="meta">${p.cat} • ${formatPrice(p.price)} / ${p.unit}</div>
            <div class="meta">${p.tags.map(t=>`<span class="tag">${t}</span>`).join(' ')}</div>
            <div class="actions">
              <a class="btn btn-olive" href="contact.html?product=${encodeURIComponent(p.name)}">تماس و استعلام</a>
              <a class="btn btn-ghost" href="#!" aria-label="مشخصات">مشخصات</a>
            </div>
          </div>
        </div>
      `).join('');
    };
    chips.forEach(c => c.addEventListener('click', () => { c.classList.toggle('active'); render(); }));
    search?.addEventListener('input', render);
    sort?.addEventListener('change', render);
    render();
  }

  // Articles page with admin-only editor (server-backed)
  if (PAGE === 'articles'){
    const list = $('.posts');
    const editor = $('.editor');
    const form = $('#postForm');
    const title = $('#title');
    const tags = $('#tags');
    const body = $('#body');
    const image = $('#image');

    async function me(){
      try{
        const r = await fetch('/api/me', {credentials:'include'});
        if (!r.ok) throw 0;
        return await r.json();
      }catch{ return {role:'guest'} }
    }
    async function load(){
      const user = await me();
      if (user.role !== 'admin') editor.style.display = 'none';
      await loadPosts();
    }
    async function loadPosts(){
      list.innerHTML = '<div class="card">در حال بارگذاری...</div>';
      try{
        const r = await fetch('/api/articles');
        const posts = await r.json();
        list.innerHTML = posts.map(p => `
          <article class="post" itemscope itemtype="https://schema.org/BlogPosting">
            ${p.image_url ? `<img src="${p.image_url}" alt="${p.title}">` : `<div class="thumb" aria-hidden="true"></div>`}
            <div class="content">
              <h3 itemprop="headline">${p.title}</h3>
              <div class="meta">
                <time datetime="${p.created_at}" itemprop="datePublished">${new Date(p.created_at).toLocaleDateString('fa-IR')}</time>
                ${(p.tags||[]).map(t=>`<span class="tag">${t}</span>`).join('')}
              </div>
              <p itemprop="articleBody">${p.body}</p>
            </div>
          </article>
        `).join('');
      }catch{
        list.innerHTML = '<div class="card">اتصال به سرور برقرار نشد.</div>';
      }
    }
    form?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData();
      fd.append('title', title.value.trim());
      fd.append('body', body.value.trim());
      fd.append('tags', tags.value.trim());
      if (image.files[0]) fd.append('image', image.files[0]);
      const r = await fetch('/api/articles', { method:'POST', body: fd, credentials:'include' });
      if (r.ok){ form.reset(); loadPosts(); window.scrollTo({top:0, behavior:'smooth'}); }
      else alert('افزودن مقاله فقط برای ادمین مجاز است یا خطایی رخ داده است.');
    });
    load();
  }

  // Contact page: prefill message if ?product= exists
  if (PAGE === 'contact'){
    const form = document.querySelector('form.mailto');
    const params = new URLSearchParams(location.search);
    const p = params.get('product');
    if (p){
      const msg = form.querySelector('#msg');
      msg.value = `سلام، درباره‌ی محصول «${p}» اطلاعات بیشتری می‌خواهم.`;
    }
    form?.addEventListener('submit', e => {
      e.preventDefault();
      const to = form.dataset.to || 'hello@zittar.ir';
      const name = form.querySelector('#name').value.trim();
      const email = form.querySelector('#email').value.trim();
      const msg = form.querySelector('#msg').value.trim();
      const subject = encodeURIComponent(`پیام وبسایت زیتار - از طرف ${name || 'مشتری'}`);
      const body = encodeURIComponent(`نام: ${name}\nایمیل: ${email}\n\n${msg}`);
      window.location.href = `mailto:${to}?subject=${subject}&body=${body}`;
    });
  }

  // Admin page (articles only)
  if (PAGE === 'admin'){
    const loginCard = $('#loginCard');
    const panel = $('#panel');
    const email = $('#a-email');
    const pass = $('#a-pass');
    const loginBtn = $('#loginBtn');
    const logoutBtn = $('#logoutBtn');
    const aList = $('#adminArticles');
    const aForm = $('#adminPostForm');
    const atitle = $('#a-title'); const atags = $('#a-tags'); const abody = $('#a-body'); const aimage = $('#a-image'); const apublished = $('#a-published');

    async function me(){
      try{
        const r = await fetch('/api/me', {credentials:'include'});
        if (!r.ok) throw 0; return await r.json();
      }catch{ return {role:'guest'} }
    }
    async function show(){
      const u = await me();
      if (u.role === 'admin'){ loginCard.style.display='none'; panel.style.display='block'; loadAdminData(); }
      else{ loginCard.style.display='block'; panel.style.display='none'; }
    }
    loginBtn?.addEventListener('click', async () => {
      const r = await fetch('/api/login', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email: email.value.trim(), password: pass.value}) , credentials:'include'});
      if (r.ok) show(); else alert('ورود ناموفق بود.');
    });
    logoutBtn?.addEventListener('click', async () => { await fetch('/api/logout', {method:'POST', credentials:'include'}); show(); });

    async function loadAdminData(){
      const r = await fetch('/api/articles?all=1', {credentials:'include'});
      const posts = await r.json();
      aList.innerHTML = posts.map(p => `
        <tr>
          <td>${p.id}</td>
          <td>${p.title}</td>
          <td>${new Date(p.created_at).toLocaleDateString('fa-IR')}</td>
          <td>${(p.tags||[]).join(', ')}</td>
          <td>${p.published ? 'منتشر' : 'پیش‌نویس'}</td>
          <td><button class="btn btn-ghost" data-del="${p.id}">حذف</button></td>
        </tr>
      `).join('');
      aList.querySelectorAll('button[data-del]').forEach(b => b.addEventListener('click', async () => {
        if (!confirm('حذف این مقاله؟')) return;
        const id = b.dataset.del;
        const r = await fetch('/api/articles/'+id, {method:'DELETE', credentials:'include'});
        if (r.ok) loadAdminData();
      }));
    }
    aForm?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData();
      fd.append('title', atitle.value.trim());
      fd.append('body', abody.value.trim());
      fd.append('tags', atags.value.trim());
      fd.append('published', apublished.checked ? '1' : '0');
      if (aimage.files[0]) fd.append('image', aimage.files[0]);
      const r = await fetch('/api/articles', {method:'POST', body: fd, credentials:'include'});
      if (r.ok){ aForm.reset(); show(); } else alert('ثبت مقاله ناموفق بود.');
    });

    show();
  }
})();
